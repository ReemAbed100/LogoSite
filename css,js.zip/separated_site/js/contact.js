document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");
    const thankYouMessage = document.getElementById("thankYouMessage");
  
    form.addEventListener("submit", function (e) {
      e.preventDefault();
  
      if (form.checkValidity()) {
        form.style.display = "none";
        thankYouMessage.style.display = "block";
  
        // Redirect after 3 seconds
        setTimeout(() => {
          window.location.href = "index.html"; // change to your home page path
        }, 3000);
      }
    });
  });
  